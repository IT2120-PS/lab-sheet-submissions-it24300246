# Set working directory
setwd("C:\\Users\\it24300246\\Desktop\\it24300246")

#  Import dataset
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")
head(branch_data)

#  Check structure
str(branch_data)
summary(branch_data)

#  Boxplot for Sales (X1)
boxplot(branch_data$Sales_X1, main="Boxplot of Sales", col="lightblue")

#  Histogram + Stem-and-leaf
hist(branch_data$Sales_X1, main="Histogram of Sales", col="orange")
stem(branch_data$Sales_X1)

#  Descriptive statistics
mean(branch_data$Advertising_X2)
median(branch_data$Advertising_X2)
sd(branch_data$Advertising_X2)

quantile(branch_data$Advertising_X2, probs=c(0.25, 0.75))  # Q1, Q3
IQR(branch_data$Advertising_X2)

#  Mode function
get_mode <- function(x) {
  uniqx <- unique(x)
  uniqx[which.max(tabulate(match(x, uniqx)))]
}
get_mode(branch_data$Years_X3)

#  Outlier detection function
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR
  upper <- Q3 + 1.5 * IQR
  x[x < lower | x > upper]
}

find_outliers(branch_data$Sales_X1)
find_outliers(branch_data$Advertising_X2)
find_outliers(branch_data$Years_X3)